from setuptools import setup

setup(name='setu',
      version='0.2',
      description='Setu\'s deeplink pckage',
      url='https://gitlab.com/setu-lobby/setu-pypi',
      author='GB',
      author_email='gandharva@setu.co',
      license='MIT',
      packages=['setu'],
      zip_safe=False)